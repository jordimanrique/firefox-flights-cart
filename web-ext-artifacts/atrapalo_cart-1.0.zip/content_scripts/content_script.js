


$('#mp3_nombre_0').val('Jordi');
$('#mp3_apellidos_0').val('Marpinez');
$('#mp3_trato_asistente_0_mr').click();
$('#mp2_use_first_asistant_data').click();
$('#mp2_email_reg').val('jordi.manrique@atrapalo.com');
$('#mp2_email_reg2').val('jordi.manrique@atrapalo.com');
$('#mp2_movil_reg').val('666777888');
$('#check_seguro_cancelacion_rechaza').click();

$('#btn_finalizar_continuar').click()

$('#mp4_tipo_tarjeta').val('VIE');